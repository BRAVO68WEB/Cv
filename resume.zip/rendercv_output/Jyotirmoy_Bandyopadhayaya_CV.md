# Jyotirmoy Bandyopadhayaya's CV

- Phone: +91 62915 59872
- Email: [hi@b68.dev](mailto:hi@b68.dev)
- Location: Kanchrapara, India
- LinkedIn: [bravo68web](https://linkedin.com/in/bravo68web)
- GitHub: [bravo68web](https://github.com/bravo68web)


# Summary

Accomplished Software Engineer with a over 3 years of professional experience  and proven track record of leading high-impact projects. Expert in optimizing performance, enhancing quality, and delivering user-centric solutions for top-tier organizations. Dedicated mentor, passionate open-source advocate, and active contributor to the developer community.

# Education

## Lovely Professional University, Bachelor of Technology in Computer Science and Engineering

- June 2020 to June 2024 
- Jalandhar, India 
- Scored GPA of 7.8/10
- Major in Cyber Security

# Experience

## [Engineer's Cradle](https://engineerscradle.com), Senior Software Developer

- Aug. 2024 to present 

- Founding Engineer and Team Lead for SaaS Product Development and Integration
- Building scalable applications and deployment workflow for product development
- Skill set :- Product Engineering, API Development, SaaS, Node.js, Go, Rust, PostgreSQL

## [SaaSDen](https://dunlin.ai), Backend Developer

- June 2023 to Nov. 2023 

- SaaS Product Development and Integration
- Build deployment workflows for the product
- Skill set :- IAM, IT Integration, API Development, Analytics, SaaS, Node.js

## [SharpSell](https://sharpsell.ai), Site Reliability Engineer

- Feb. 2023 to Apr. 2023 

- Infrastructure Management as AWS Administartor
- Skill set :- AWS, CodeBuild, CodePipeline, ECS, EC2, ECR, GitHub Actions

## [Hybr1d](https://zenadmin.io), SDE Intern

- July 2022 to Dec. 2022 

- Developed and maintained the backend of the Hybr1d platform
- Migrated from Ruby on Rails to TypeScript
- Skill set :- Node.js, Express.js, MongoDB, REST API, JWT, PostgreSQL, Hasura, GraphQL

## [Engineer's Cradle](https://engineerscradle.com), DevOps Engineer

- Jan. 2021 to Jan. 2022 

- Developed and Deployed scalable applications
- Skill set :- CI/CD, Docker, Gitlab, AWS, Deployment Planning, DevOps, Git

# Projects

## [Pacsearch](https://github.com/BRAVO68WEB/pacsearch)

- June 2024 - Pacman Package Finder for Arch Linux
- Indexed over 130,000 Arch Linux packages
- Tech Stack: Next.js, TypeScript, TailwindCSS, Rust, Github Actions, GraphQL, PostgreSQL

## [Zer0bin](https://github.com/BRAVO68WEB/zer0bin)

- Apr. 2024 - Place to paste code/text and share with others
- Tech Stack: Pug, Vite, TypeScript, Rust, Github Actions, GraphQL, PostgreSQL

## [SHX](https://github.com/BRAVO68WEB/shx)

- Aug. 2023 - Shx is a platform ment to store and share files, images, text and URLs with ease. 
- Tech Stack: Next.js, TypeScript, TailwindCSS, Express, Cloudflare

## [NPM ez Dependency Adder](https://github.com/brag-club/npm-ez-dependency-adder)

- Feb. 2024 - Easily install npm dependencies on a single go
- Tech Stack: Next.js, TypeScript, TailwindCSS, NPM, Cloudflare

## [Synode](https://github.com/TheNestDevs/synode)

- June 2024 - Won 2nd place in HackForBengal 2024
- Synode (pronounced sai-node) is payment app from the future, to unplug and pay. Supports offline payments
- Tech Stack: TypeScript, AVAX Blockchain, Flutter, Dart, AWS, Cloudflare

# Certifications

## [Certified Ethical Hacker v12](https://safe.b68dev.xyz/Kz7jk0O8.pdf) by [EC-Council](https://www.eccouncil.org/)

- Apr. 2024 
## [Certified Penetration Testing Specialist](https://www.credly.com/badges/d3c0c02e-4946-4ecb-a513-be4d2be8f812) by [HackTheBox](https://www.hackthebox.com/)

- July 2024 
# Skills

- Web Development: HTML, CSS, JavaScript, Node.js, Express.js, React.js, Next.js
- Programming: Python, JavaScript, TypeScript, C++, Rust, Go, Shell
- Databases: PostgreSQL, SQLite, Redis, MySQL, MongoDB
- Tools: Postman, Vim, VS Code, Git, GitHub, Nginx
- DevOps: AWS, Heroku, Netlify, Vercel, DigitalOcean, Google Cloud, Azure, GitHub Actions, CodeBuild, CodePipeline, ECS, EC2, ECR, GCP, Azure
- Cyber Security: CEHv12, CPTS, Security Researcher, CTF Player, OWASP, DevSecOps, Nmap, Burp Suite, Metasploit, Wireshark, WPScan, Nessus, Nikto, OSINT
