# Shruti S's CV

- Phone: +91 63825 80602
- Email: [shruti.sundar0405@gmail.com](mailto:shruti.sundar0405@gmail.com)
- Location: Chennai, TamilNadu, India
- LinkedIn: [Shruti-S0405](https://linkedin.com/in/Shruti-S0405)
- GitHub: [Shruti-S0405](https://github.com/Shruti-S0405)


# Summary

Eager and driven Computer Science and Engineering student seeking opportunities to apply academic knowledge, enhance skills, and contribute to innovative projects. Passionate about leveraging technology to solve real-world problems and keen to learn and grow in a dynamic environment.

# Education

## Panimalar Engineering College, Bachelor of Engineering in Computer Science and Engineering

- June 2022 to June 2026 
- Chennai, TamilNadu, India 
- Scored CGPA of 9/10

# Experience

## Cognizant, Intern

- July 2024 to Aug. 2024 

- Built an AI/ML application with a focus on GenAI in the Medicare Domain
- Skill set :- AngularJS, Python(Flask), Semantic Kernel, Okta, Azure LLM, MS SQL Server

# Projects

## [SoundSynth](https://github.com/Shruti-S0405)

- 2024-03-2024 - Converts audio files directly to summarized text for better and short reading.
- Uses Deepgram API for Audio processing and Leverages Gemini 1.5 Pro API to summarization.
- Tech Stack: ReactJS, Vite, NodeJS, Cloudflare R2, Cloudflare Workers, Gemini.

## [CodeSense](https://github.com/Shruti-S0405/CodeSense)

- May 2024 - Leverages Gemini 1.5 Pro API to summarization
- Supports JS, Python, C, C++, Java, etc ...
- Tech Stack: ReactJS, Vite, NodeJS, Cloudflare Workers, Gemini

## [ScanMe - QR Generator](https://github.com/Shruti-S0405/ScanMe)

- June 2024 - Create QR Code with ease to share Links, Messages, etc ...
- Tech Stack: ReactJS, Vite, NodeJS, Cloudflare Workers, Gemini

# Certifications

## [Github Foundation](https://www.credly.com/badges/f3c9792a-9ba8-4535-b9a2-f05bd0abca66) by [Github](https://www.github.com/)

- Aug. 2024 
## [Oracle Cloud Infrastructure 2024 Generative AI Certified Professional](https://safe.b68dev.xyz/H1qf64oC.pdf) by [Oracle Cloud](https://cloud.oracle.com/)

- July 2024 
# Skills

- Web Development: HTML, CSS, JavaScript, Node.js, Express.js, React, Angular
- Programming: Java, JavaScript, C++, C, Python
- Databases: MySQL, Microsoft SQL Server
- Tools: Postman, VS Code, Git, GitHub
- DevOps: Netlify, Vercel, Cloudflare, Azure
